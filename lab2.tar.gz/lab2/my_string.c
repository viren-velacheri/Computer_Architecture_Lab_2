#include "my_string.h"
// Name: Viren Velacheri  EID: vv6898
// Note: References I used included all in pdf including the wikibooks site
// that through the public implementations given gave hints to do a lot of
// these C problems.
#define NULL_TERMINATED '\0'
// These below constants are used in multiple methods, hence macros.
// Two of them hold same value but stand for different things
#define NOT_FOUND -1
#define FOUND 0
#define STOP 0
/* This method basically copies the num bytes of source string over to the
destination string. It overwrites any existing characters that may be present
in destination. */
char * my_strncpy ( char * destination, const char * source, size_t num)
{
  // This is the index pointer that goes num characters in source and is
  // used for copying those characters over to the respective spot in
  // destination
  int index = 0;
  // This loop simply copies over characters from source to destination until
  // either source reaches null terminating character or index is greater than
  // num.
  while(source[index] != NULL_TERMINATED && index < num) {
    destination[index] = source[index];
    index++;
  }
  // If index is still less than size num, then that means a null terminating
  // symbol must have been reached in source. Therefore for the rest of num
  // spots to copy over, the rest of destination is filled with null terminating
  // characters or zeros.
  while(index < num) {
    destination[index] = NULL_TERMINATED;
    index++;
  }
  return destination;
}

/* This method basically returns a pointer to the first occurence of given
character in the str string */
char* my_strchr (char* str, int character)
{
  // The below variable basically converts the int character into it's actual
  // char value.
  char charToFind = character;
  // This loop goes til we reach end of str or null terminating symbol or
  // until we find the character in str.
  while(*str != NULL_TERMINATED && *str != charToFind) {
    str++;
  }
  // If character was found, that means we stopped at the index in string that
  // it was found and so we just return the pointer to that spot in str.
  // Otherwise, return NULL as that means we reached null terminating/end of
  // string and didn't find character.
  if(*str == charToFind) {
    return str;
  } else {
    return NULL;
  }
}

/* This method basically copies values of num bytes from the location pointed
to by source to the memoery block pointed by destination. It is similar to
strncpy except the copying takes place as if an immediate buffer were being
used, allowing source and destination to overlap. */
void* my_memmove (void* destination, const void* source, size_t num)
{
  // the below variables are used as pointers to the destination and source
  // respectively.
  char *destPoint = destination;
  const char *sourcePoint = source;
  // Check to see if character pointed to by source is less than that pointed
  // to by the destination pointer. Also check to make sure character pointed
  // by destination is less than that of source pointer and num. If so,
  // both sourcePointer and destination pointer are incremented by num. Then
  // a while loop where as long as num isn't zero, both pointers are
  // decremented. If checks in if aren't satisfied, has a while loop instead
  // where the opposite is done as the pointers are incremented and destination
  // pointer is set like above.
  if(sourcePoint < destPoint && destPoint < sourcePoint + num) {
    sourcePoint += num;
    destPoint += num;
    while(num != STOP) {
      *--destPoint = *--sourcePoint;
      num--;
    }
  } else {
    while(num != STOP) {
      *destPoint++ = *sourcePoint++;
      num--;
    }
  }
  return destination;
}

/* This method basically appends the first num characters of the source to
destination and if sources terminates earlier than num, then it stops there.*/
char* my_strncat (char* destination, const char* source, size_t num)
{
  // Two index pointers are used for going through both the destination as well
  // as source strings.
  int destIndex = 0;
  int sourceIndex = 0;
  // This loop simply runs til the null terminating character in destination
  while(destination[destIndex] != NULL_TERMINATED) {
    destIndex++;
  }
  // This loop runs and is what allows for the appending of characters from
  // the source to the destination until num is fulfilled or the null
  // terminating symbol in source string is reached.
  while(num != STOP && source[sourceIndex] != NULL_TERMINATED) {
    num--;
    destination[destIndex] = source[sourceIndex];
    destIndex++;
    sourceIndex++;
  }
  // If last character of destination isn't null terminated, that part is added.
  if(destination[destIndex] != NULL_TERMINATED) {
    destination[destIndex] = NULL_TERMINATED;
  }
  return destination;
}

/* This method basically num number of characters of two strings. If str1 is
bigger, then a positive number (> 0) is returned. If str2 is bigger, then a
negative number (< 0) is returned. If the num characters compared are same
or both null terminate early, then zero is returned. */
int my_strncmp (const char* str1, const char* str2, size_t num)
{
  // Both these chars are used to contain the characters that differ.
  unsigned char diff1, diff2;
  // if num is zero at the very beginning, then nothing to compare so
  // zero is returned. Otherwise, set two indices for str1 and str2
  // respectively to traverse the two strings and compare them.
  const int smaller = -1; // For the comparison below
  if(num == STOP) {
    return 0;
  } else {
    // this loop basically goes until we compare all num amount of characters in
    // the strings or when the characters are found to be different or the first
    // difference that is found.
    while(num != STOP && (*str1 == *str2)) {
      num--;
      if(num == STOP || *str1 == NULL_TERMINATED) {
        return 0;
      }
      str1++;
      str2++;
    }
    // If differing character of 1st string is less than other one,then
    // a negative value (-1) is returned. Otherwise, simply return 1 if
    // greater via the comparison in else.
    diff1 = (*(unsigned char *) str1);
    diff2 = (*(unsigned char *) str2);
    if(diff1 < diff2) {
      return smaller;
    } else {
      return (diff1 > diff2);
    }
  }
}

/* This method is basically the same as the above method except it compares
the whole string and not just an n amount of bytes. Return values are the same
as well */
int my_strcmp (const char* str1, const char* str2)
{
  int index1 = 0; // index pointer for str1
  int index2 = 0; // index pointer for str2
  // This loop goes until the characters in the strings differ
  // (or when the first difference is found) or if when equal and they have
  // reached a null terminating symbol, just return 0.
  while(str1[index1] == str2[index2]) {
    if(str2[index2] == NULL_TERMINATED) {
      return 0;
    }
    index1++;
    index2++;
  }
  return str1[index1] - str2[index2]; // returns the respective difference.
}

/* This method basically goes through string and tries to find the last
occurence of character in string. If no occurence is found at all, NULL is
returned. Else, a pointer to the last occurence of character in string is
returned. */
char* my_strrchr (char* str, int character)
{
  // updates based on whether character is found or not. For each occurence
  // of character found, the index of found is changed to store the latest
  // index of occurence.
  int found = NOT_FOUND;
  int index = 0; // the index pointer that goes through str.
  // This loop goes on til we reach null terminating character. For each
  // character found, found variable is set to that index. Then at end if found
  // is found to still be -1, that means no occurence of character was found,
  // hence NULL was returned. Otherwise, return the pointer to last character in
  // string using found that stores that index.
  while(*str != NULL_TERMINATED) {
    if(*str == character) {
      found = index;
    }
    str++;
    index++;
  }
  if(character == NULL_TERMINATED) {
    return str;
  } else if(found != NOT_FOUND) {
    // The below variable determines the number of spots to shift the pointer
    // back to get to last occurence of character found.
    int shift = index - found;
    while(shift != STOP) {
      str--;
      shift--;
    }
    return str;
  } else {
    return NULL;
  }
}

/* This method see whether the second string is within the first and if so,
returns a pointer to this first occurence. If no occurence found, zero is
returned. */
char* my_strstr (char *str1, const char *str2)
{
  // The below variable is a pointer to the first string. Set it to a constant
  // string to be used in a comparison method below.
  const char *temp = str1;
  // This is checking for corner case where both are empty strings.
  if(*str1 == NULL_TERMINATED && *str2 == NULL_TERMINATED) {
    return temp;
  }
  // This loops til we reach null terminating symbol at the end.
  while(*temp != NULL_TERMINATED) {
    // the helper method is used to check and see whether the pointer at temp
    // onwards matches substring 2. If so zero is returned and the pointer of
    // this first occurence is returned. otherwise, simply exit out and
    // increment pointer.
    if(foundOrNot(temp, str2) == FOUND) {
      return temp;
    }
    temp++;
  }
  return NULL; // If no occurence found, this is returned.
}

/* This is a helper method used for determining whether substring 2 exists
at first string pointer onwards. */
int foundOrNot(const char *str1, const char *str2) {
  // This loops through until a difference is found or whene the substring
  // (str2) reaches null terminating symbol. When str2 reaches null terminating
  // symbol we know that up til that point all characters matched so 0 is
  // returned to indicate this. Otherwise -1 is returned.
  while(*str1 == *str2 && *str2 != NULL_TERMINATED) {
    str1++;
    str2++;
  }
  if(*str2 == NULL_TERMINATED) {
    return FOUND;
  } else {
    return NOT_FOUND;
  }
}
